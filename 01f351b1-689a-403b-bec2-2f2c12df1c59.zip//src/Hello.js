import React from "react";

function Hello() {
  return <h2>Hello from a new React component! 🎉</h2>;
}

export default Hello;
