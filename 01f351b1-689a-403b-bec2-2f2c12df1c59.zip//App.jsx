// App.jsx
import React, { useEffect, useRef } from "react";
import "./App.css";

function App() {
  const blackSectionRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
        }
      },
      {
        threshold: 0.1, // Trigger when 10% of the section is visible
      }
    );

    if (blackSectionRef.current) {
      observer.observe(blackSectionRef.current);
    }

    return () => {
      if (blackSectionRef.current) {
        observer.unobserve(blackSectionRef.current);
      }
    };
  }, []);

  return (
    <div className="App">
      <section className="white-section">
        <div className="content">
          <h1>Welcome</h1>
          <p>This is the white section with light content.</p>
          <p>Scroll down to see the transition effect.</p>
        </div>
      </section>

      <section className="black-section" ref={blackSectionRef}>
        <div className="content">
          <h1>Discover</h1>
          <p>This is the black section with dark content.</p>
          <p>The transition happens smoothly as you scroll.</p>
        </div>
      </section>
    </div>
  );
}

export default App;


import React, { useEffect, useRef } from "react";
import "./App.css";